package Classes.Composicao;

public class Motor {
    private int cilindrada;

    public Motor() {
        this.cilindrada = 1600;
    }

    public int getCilindrada() {
        return cilindrada;
    }
}