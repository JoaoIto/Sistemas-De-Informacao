package src.classes;

public interface Impressao {
    void imprimir();
}
