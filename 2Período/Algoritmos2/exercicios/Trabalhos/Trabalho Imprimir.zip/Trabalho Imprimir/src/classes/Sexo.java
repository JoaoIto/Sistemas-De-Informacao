package src.classes;

public enum Sexo {
    MASCULINO, FEMININO
}
