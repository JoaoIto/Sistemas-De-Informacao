package app;
import java.util.Scanner;
import classes.Carros;
import classes.Motos;
import classes.Veiculos;
import classes.Corrida;

public class main {
	
	public static void cadastra() {
		Scanner scan = new Scanner(System.in);
		Veiculos[] veiculos = new Veiculos[4]; 
		
		System.out.println("Vamos começar o cadastro dos carros de corrida!");
		
		for(int i = 0; i < veiculos.length; i++) {
			System.out.println("Insira os dados dos veiculos");
			
			System.out.println("Deseja continuar cadastrando veiculos? Digite 1 para SIM e 2 para NÃO.");
            int repete = scan.nextInt();
            
            if(repete == 2) {
            	for(int y = 0; y < veiculos.length; y++) {
        			System.out.println("Dados dos veiculos(carros): " + ("Posicao: ")+ (y + 1 + " ") + "Marca: " +  veiculos[y].carro.marca + ("/") + "Modelo: " + veiculos[y].carro.modelo + ("/") + "Ano: " + veiculos[y].carro.ano + ("/") + "Peso: " + veiculos[y].carro.peso + ("/") + "Cilindrada: " + veiculos[y].carro.cilindrada);
        			System.out.println("Dados dos veiculos(motos): " + ("Posicao: ")+ (y + 1 + " ") + "Marca: " +  veiculos[y].moto.marca + ("/") + "Modelo: " + veiculos[y].moto.modelo + ("/") + "Ano: " + veiculos[y].moto.ano + ("/") + "Peso: " + veiculos[y].moto.peso + ("/") + "Cilindrada: " + veiculos[y].moto.cilindrada);
        		}
            }
            
			System.out.println("Insira 1 se quiser inserir um carro, se uma moto, digite 2:");
			veiculos[i] = new Veiculos();
			veiculos[i].tipo = scan.nextInt();
			
			if(veiculos[i].tipo == 1) { 
				for(int x = 0; x < veiculos.length; x++) {
					veiculos[x].carro = new Carros();
					
					Carros.cadastro(veiculos[x].carro);
					
					System.out.println("Deseja continuar cadastrando carros? Digite 1 para SIM e 2 para NÃO.");
		            int seletor = scan.nextInt();
		            
		            if(seletor == 2) {
		            	break;
		            }
				}
			}
			else {
				for(int j = 0; j < veiculos.length; j++) {
					veiculos[j].moto = new Motos();
					
					Motos.cadastro(veiculos[j].moto);
					
					System.out.println("Deseja continuar cadastrando motos? Digite 1 para SIM e 2 para NÃO.");
		            int seletor = scan.nextInt();
		            
		            if(seletor == 2) {
		            	Carros[] carros = new Carros[4];
		                Motos[] motos = new Motos[4];
		                corrida(carros, motos);
		            }
				}
			}
		}
	}

	public static void corrida(Carros[] carrosLista, Motos[] motosLista){
        Corrida.corridaCarros(carrosLista);
        Corrida.corridaMotos(motosLista);
    }
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Bem Vindo a corrida!");
		System.out.println("Deseja fazer cadastro de novos veículos, se sim digite 1, se quiser iniciar corrida, digite 2: ");
		int escolha = scan.nextInt();
		
		if(escolha == 1) {
			cadastra();
		}
	}
}
