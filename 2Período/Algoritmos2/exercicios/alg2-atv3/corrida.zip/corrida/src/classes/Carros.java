package classes;

import java.util.Scanner;

public class Carros {
	public String marca;
	public String modelo;
	public int ano;
	
	// Dados para cálculo;
	
	public double peso;
	public int cilindrada;
	public double velocidade;
	public int tempo;
	public double aceleracao = 5 + (0.15 * cilindrada) - (peso / 300);
	
	public static void cadastro(Carros carros) {
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Marca:\nModelo:\nAno:\nPeso:\nCilindrada:");
		
		carros.marca = scan.next();
		carros.modelo = scan.next();	
		carros.ano = scan.nextInt();
		carros.peso = scan.nextInt();
		carros.cilindrada = scan.nextInt();
	}
}