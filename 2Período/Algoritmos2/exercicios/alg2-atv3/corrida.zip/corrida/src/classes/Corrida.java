package classes;

public class Corrida {

    public static double frear(Double velocidade){
        velocidade *= 0.75;
        return velocidade;
    }
    
    public static double acelerar(Double velocidade, Integer cilindrada, Double peso){
        int redutorPeso = 0;
        for (int i = 0; i < peso; i++) {
            if (peso % 300 == 0)
                redutorPeso++;
        } // verifica quanto vai ser reduzido na velocidade devido ao peso

        velocidade = (velocidade + 5);
        velocidade += ((velocidade*(0.15*cilindrada)) - redutorPeso);
        return velocidade;
    }
    
	public static void corridaCarros(Carros[] carrosCorrida) {
		for(int t = 0; t < 20; t++) {
			if(t == 6 || t == 11 || t == 15) {
				for (Carros carros : carrosCorrida) {
                    if(carros != null)
                        carros.velocidade = frear(carros.velocidade);
                }
			}else {
				System.out.println("Aceleração!");
				for (Carros carros : carrosCorrida) {
                    if(carros != null)
                        carros.velocidade = acelerar(carros.velocidade, carros.cilindrada, carros.peso);
                }
			}
		}
	}
	
	 public static void corridaMotos(Motos[] motosCorrida){
	        for (int t = 0; t < 20; t++) {
	            if(t == 6 || t == 11 || t == 15){
	                for (Motos motos : motosCorrida) {
	                    if(motos != null)
	                        motos.velocidade = frear(motos.velocidade);
	                }
	            }
	            else{
	                for (Motos motos : motosCorrida) {
	                    if(motos != null)
	                        motos.velocidade = acelerar(motos.velocidade, motos.cilindrada, motos.peso);
	                }
	            }
	        }
	 }
}