package classes;
import classes.Carros;
import classes.Motos;

public class Veiculos {
	public int tipo; // Caso 1 == carro; Caso 2 == moto;
	public Carros carro;
	public Motos moto;
}