# Tabela Verdade Java

Desenvolver um programa para a resolução de uma tabela verdade
com entrada de duas proprosições, sendo (p e q), utilizados para
formar uma proposições ou expressão, sendo possível atribuir os valores
entre V ou F, e assim trabalhando os conectivos das operações, sendo ainda
no final que deve ser informada a saída dos valores e conectivos dados
na entrada.

## Console test: 

<img src="./.github/tabelaVerdade-Java.png"/>

---